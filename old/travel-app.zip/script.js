
const trip=[{day:"Giorno 1",sections:{Mattino:[{t:"Colmar",time:"09:00",km:"18 km",dur:"22 min"}],Pomeriggio:[{t:"Castello",time:"14:00",km:"62 km",dur:"55 min"}],Sera:[{t:"Hotel",time:"19:00",km:"-",dur:"-"}]}},
{day:"Giorno 2",sections:{Mattino:[{t:"Strasburgo",time:"09:00",km:"5 km",dur:"15 min"}],Pomeriggio:[],Sera:[]}}];
let total=0,done=0,next=null;
const days=document.getElementById('days');
trip.forEach((d,di)=>{
 let wrap=document.createElement('div');wrap.className='day';
 let h=document.createElement('div');h.className='head';h.textContent='📅 '+d.day+' ▼';
 let c=document.createElement('div');c.className='content'+(di==0?' open':'');
 h.onclick=()=>c.classList.toggle('open');
 for(const [name,arr] of Object.entries(d.sections)){
  let s=document.createElement('div');s.className='sec';s.innerHTML='<h3>'+name+'</h3>';
  arr.forEach((p,pi)=>{
   total++;
   const id=`${di}-${name}-${pi}`;
   let chk=localStorage.getItem(id)==='1';
   if(!next && !chk) next=p;
   if(chk) done++;
   let div=document.createElement('div');div.className='card';
   div.innerHTML=`<label><input type=checkbox ${chk?'checked':''}> <b>${p.time}</b> ${p.t}</label>
   <small>🚗 ${p.km} • ⏱ ${p.dur}</small>
   <a class="btn" target="_blank" href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(p.t)}">📍 Google Maps</a>
   <details><summary>📝 Note</summary><textarea style="width:100%"></textarea></details>`;
   div.querySelector('input').onchange=e=>{localStorage.setItem(id,e.target.checked?'1':'0');location.reload()}
   s.appendChild(div);
  });
  c.appendChild(s);
 }
 wrap.append(h,c);days.appendChild(wrap);
});
let pct=Math.round(done*100/Math.max(total,1));prog.value=pct;document.getElementById('pct').textContent=pct+'%';
document.getElementById('next').onclick=()=>{if(next)window.open('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(next.t))}
if('serviceWorker' in navigator) navigator.serviceWorker.register('service-worker.js');
